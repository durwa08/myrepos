A small Python utility that validates and manages member data using
Dictionaries, Lists, OOP, custom exceptions, regex, and functional programming.

pip install dist/data_processor_task-1.0.0-py3-none-any.whl

from my_processor.core import Member
member = Member("John Doe", "john@example.com", "555-0101")
