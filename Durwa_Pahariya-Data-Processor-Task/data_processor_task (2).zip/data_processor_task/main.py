from my_processor.core import process_members, filter_members_by_domain

raw_members = [
    {"name": "John Doe", "email": "john.doe@example.com", "phone": "555-0101"},
    {"name": "Jane Smith", "email": "jane.smith@...com", "phone": "555-0102"},
    {"name": "InvalidData", "email": "", "phone": "555-0103"},
]

if __name__ == "__main__":
    members = process_members(raw_members)


    example_domain_members = filter_members_by_domain(members, "example.com")
    print(f"\nMembers with @example.com email: {[m.name for m in example_domain_members]}")
