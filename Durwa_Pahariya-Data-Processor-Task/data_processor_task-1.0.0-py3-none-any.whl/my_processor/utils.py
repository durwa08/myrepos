import re

EMAIL_PATTERN = r'^[\w\.\+\-]+@[\w\-]+\.[a-zA-Z]{2,}$'
PHONE_PATTERN = r'^\d{3}-\d{4}$'

def validate_email(email: str) -> bool:
    """Return True if email matches a valid pattern."""
    if not email:
        return False
    return bool(re.match(EMAIL_PATTERN, email.strip()))

def validate_phone(phone: str) -> bool:
    """Return True if phone matches XXX-XXXX pattern."""
    if not phone:
        return False
    return bool(re.match(PHONE_PATTERN, phone.strip()))

def clean_name(name: str) -> str:
    """Trim whitespace and title-case the name."""
    return name.strip().title() if name else ""
