from my_processor.utils import validate_email, validate_phone, clean_name


class InvalidMemberDataError(Exception):
    """Raised when member data (email/phone/name) is invalid or missing."""
    def __init__(self, member_name, message="Invalid member data"):
        self.member_name = member_name
        self.message = f"{message} for member '{member_name}'"
        super().__init__(self.message)


class Member:
    def __init__(self, name, email, phone):
        self.name = clean_name(name)
        self.email = email
        self.phone = phone

    def __repr__(self):
        return f"Member(name={self.name}, email={self.email}, phone={self.phone})"


def validate_member_data(raw_member: dict) -> Member:
    """Validate a raw dict and return a Member object, or raise InvalidMemberDataError."""
    name = raw_member.get("name", "").strip()
    email = raw_member.get("email", "").strip()
    phone = raw_member.get("phone", "").strip()

    if not name:
        raise InvalidMemberDataError("InvalidData", "Missing name")

    if not validate_email(email):
        raise InvalidMemberDataError(name, "Invalid email")

    if not validate_phone(phone):
        raise InvalidMemberDataError(name, "Invalid phone")

    return Member(name, email, phone)


def process_members(raw_members: list) -> list:
    """Process a list of raw member dicts, return list of valid Member objects."""
    valid_members = []
    success_count = 0

    for raw in raw_members:
        name_for_log = raw.get("name", "Unknown")
        try:
            print(f"Processing member: {name_for_log}...", end=" ")
            member = validate_member_data(raw)
            print("Validation Successful.")
            valid_members.append(member)
            success_count += 1
        except InvalidMemberDataError as e:
            print()  # newline after the "Processing..." text
            print(f"Error: {e.message}. Skipping.")
        except Exception as e:
            print()
            print(f"Unexpected error: {e}. Skipping.")

    print(f"\nSummary: {success_count} members processed successfully.")
    return valid_members


def filter_members_by_domain(members: list, domain: str) -> list:
    """Example use of lambda + filter(): filter members by email domain."""
    return list(filter(lambda m: m.email.endswith(domain), members))
